# 🏕️ LandScout - Sheriff Sale & Tax Auction Aggregator

**The "Zillow for Off-Gridders"** - A comprehensive platform to find affordable land through sheriff sales, tax deed auctions, foreclosures, and surplus property sales.

## 🎯 Vision

Help digital nomads, RV dwellers, and alternative lifestyle seekers find affordable land by aggregating fragmented auction data from hundreds of county sources into one searchable platform with AI-powered analysis.

## 🗂️ Project Structure

```
land-scout/
├── app.jsx                    # Main React application (working prototype)
├── naca-calculator.jsx        # NACA affordability calculator component
├── database/
│   └── schema.sql            # PostgreSQL database schema
└── docs/
    └── DATA_SOURCES.md       # Comprehensive API & data source guide
```

## ✨ Features (MVP)

### Currently Built:
- ✅ Property grid with filtering (state, auction type, price, acres)
- ✅ RV/Mobile Home friendly filters
- ✅ Flood zone filtering
- ✅ AI scoring system (0-100) with verdicts
- ✅ Property detail view with analysis
- ✅ Direct links to auction platforms
- ✅ Platform directory by state
- ✅ NACA affordability calculator

### Data Points Tracked:
- Address, coordinates, parcel ID
- Auction type (tax deed, sheriff sale, foreclosure, listing)
- Auction date/time and platform links
- Opening bid vs estimated value (discount %)
- Acreage and zoning
- RV/Mobile home allowance
- Utilities (water, electric, sewer)
- Flood zone
- AI analysis with reasons to buy & risk factors

## 🚀 Quick Start

### Run the Main App:
```bash
# Copy app.jsx to your React project or use it as a standalone artifact
# The component is self-contained with embedded styles
```

### Setup Database:
```bash
# With Supabase or PostgreSQL
psql -d your_database -f database/schema.sql
```

## 📊 Data Sources

See `docs/DATA_SOURCES.md` for complete documentation on:
- Florida RealAuction platforms (tax deeds, foreclosures)
- Georgia county tax sales
- Free property data APIs
- Scraping strategies
- AI integration guides
- Trulli.ai lender integration

## 💰 Your Personal Estimate (Based on $55k/year, $800/mo debts)

With NACA's program:
- **Max monthly payment:** ~$1,170
- **Estimated loan approval:** $115,000 - $125,000
- **No down payment, no PMI, no closing costs**

This gives you solid buying power for land in:
- North Georgia (Ranger, Ellijay): $5k-$30k for 1-3 acres
- Tampa area (Pasco, Hernando): $10k-$35k for 0.2-0.5 acres

## 🛠️ Tech Stack Recommendations

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js + React |
| Database | Supabase (PostgreSQL) |
| Scraping | Puppeteer + BullMQ |
| Maps | Mapbox |
| AI | Claude API / OpenAI |
| Hosting | Vercel |

## 📋 Roadmap

### Phase 1 (Weeks 1-2)
- [ ] Deploy MVP with manual property data
- [ ] Basic filters and search
- [ ] NACA calculator integration

### Phase 2 (Weeks 3-4)
- [ ] Automated scraping for FL/GA counties
- [ ] User accounts
- [ ] Saved properties

### Phase 3 (Weeks 5-6)
- [ ] AI property scoring
- [ ] Email alerts
- [ ] Trulli.ai lender integration

### Phase 4 (Ongoing)
- [ ] Expand to more states
- [ ] Mobile app
- [ ] Premium features

## 🤝 Trulli.ai Integration

With access to Trulli.ai's lender network, you can:
1. Pre-qualify users based on their financial profile
2. Match properties with appropriate lenders
3. Streamline the financing process for land purchases

## 📄 License

MIT - Build something great!

---

Built with 💙 for the off-grid community
