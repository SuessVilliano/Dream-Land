import React, { useState, useMemo } from 'react';
import { Calculator, DollarSign, Home, TrendingUp, Info, CheckCircle, AlertTriangle, PiggyBank, CreditCard, Briefcase } from 'lucide-react';

export default function NACACalculator() {
  const [income, setIncome] = useState(55000);
  const [monthlyDebts, setMonthlyDebts] = useState(800);
  const [interestRate, setInterestRate] = useState(5.0);
  const [loanTerm, setLoanTerm] = useState(30);
  
  const results = useMemo(() => {
    const monthlyGross = income / 12;
    
    // NACA guidelines
    const frontEndLimit = 0.31; // Housing payment only
    const backEndLimit = 0.43;  // Total debt
    
    const maxHousingFromFrontEnd = monthlyGross * frontEndLimit;
    const maxTotalDebt = monthlyGross * backEndLimit;
    const availableForHousing = maxTotalDebt - monthlyDebts;
    
    // Use the lower of the two
    const maxPayment = Math.min(maxHousingFromFrontEnd, availableForHousing);
    
    // Calculate max loan (standard mortgage formula)
    const monthlyRate = (interestRate / 100) / 12;
    const termMonths = loanTerm * 12;
    
    const maxLoan = maxPayment * 
      ((Math.pow(1 + monthlyRate, termMonths) - 1) / 
      (monthlyRate * Math.pow(1 + monthlyRate, termMonths)));
    
    // Calculate current DTI ratios
    const currentBackEndDTI = (monthlyDebts / monthlyGross) * 100;
    const projectedBackEndDTI = ((maxPayment + monthlyDebts) / monthlyGross) * 100;
    
    // Estimate property taxes and insurance for land
    const estimatedTaxesInsurance = 150; // Lower for land vs house
    const netForMortgage = maxPayment - estimatedTaxesInsurance;
    
    const adjustedMaxLoan = netForMortgage * 
      ((Math.pow(1 + monthlyRate, termMonths) - 1) / 
      (monthlyRate * Math.pow(1 + monthlyRate, termMonths)));
    
    return {
      monthlyGross: Math.round(monthlyGross),
      maxHousingPayment: Math.round(maxHousingFromFrontEnd),
      availableAfterDebts: Math.round(availableForHousing),
      effectiveMaxPayment: Math.round(maxPayment),
      maxLoanAmount: Math.round(maxLoan),
      adjustedMaxLoan: Math.round(adjustedMaxLoan),
      currentBackEndDTI: currentBackEndDTI.toFixed(1),
      projectedBackEndDTI: projectedBackEndDTI.toFixed(1),
      frontEndDTI: ((maxPayment / monthlyGross) * 100).toFixed(1),
      isQualified: availableForHousing > 0 && currentBackEndDTI < 43,
      limitingFactor: availableForHousing < maxHousingFromFrontEnd ? 'back-end' : 'front-end'
    };
  }, [income, monthlyDebts, interestRate, loanTerm]);

  return (
    <div className="naca-calculator">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        
        .naca-calculator {
          font-family: 'Space Grotesk', sans-serif;
          background: linear-gradient(135deg, #0a0f1a 0%, #0d1524 50%, #0f1a2e 100%);
          min-height: 100vh;
          padding: 2rem;
          color: #e2e8f0;
        }
        
        .calc-container {
          max-width: 1000px;
          margin: 0 auto;
        }
        
        .calc-header {
          text-align: center;
          margin-bottom: 2rem;
        }
        
        .calc-header h1 {
          font-size: 2rem;
          font-weight: 700;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 0.5rem;
        }
        
        .calc-header p {
          color: #94a3b8;
          font-size: 1rem;
        }
        
        .calc-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 2rem;
        }
        
        @media (max-width: 768px) {
          .calc-grid {
            grid-template-columns: 1fr;
          }
        }
        
        .input-section {
          background: rgba(15, 23, 42, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 16px;
          padding: 1.5rem;
        }
        
        .section-title {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 1.1rem;
          font-weight: 600;
          color: #f8fafc;
          margin-bottom: 1.5rem;
          padding-bottom: 0.75rem;
          border-bottom: 1px solid rgba(59, 130, 246, 0.2);
        }
        
        .section-title svg {
          color: #3b82f6;
        }
        
        .input-group {
          margin-bottom: 1.5rem;
        }
        
        .input-group label {
          display: block;
          font-size: 0.85rem;
          color: #94a3b8;
          margin-bottom: 0.5rem;
        }
        
        .input-row {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        
        .input-wrapper {
          flex: 1;
          position: relative;
        }
        
        .input-wrapper .prefix {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: #64748b;
          font-size: 1rem;
        }
        
        .input-wrapper input {
          width: 100%;
          padding: 0.875rem 1rem 0.875rem 2rem;
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 10px;
          color: #f8fafc;
          font-family: 'JetBrains Mono', monospace;
          font-size: 1.1rem;
          transition: all 0.2s;
        }
        
        .input-wrapper input:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
        
        .value-display {
          font-family: 'JetBrains Mono', monospace;
          font-size: 1rem;
          color: #60a5fa;
          min-width: 100px;
          text-align: right;
        }
        
        input[type="range"] {
          width: 100%;
          height: 6px;
          -webkit-appearance: none;
          background: rgba(59, 130, 246, 0.2);
          border-radius: 3px;
          margin-top: 0.5rem;
        }
        
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 18px;
          height: 18px;
          background: #3b82f6;
          border-radius: 50%;
          cursor: pointer;
          box-shadow: 0 2px 6px rgba(59, 130, 246, 0.4);
        }
        
        /* Results Section */
        .results-section {
          background: rgba(15, 23, 42, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 16px;
          padding: 1.5rem;
        }
        
        .qualification-badge {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 1rem;
          border-radius: 12px;
          font-size: 1.1rem;
          font-weight: 600;
          margin-bottom: 1.5rem;
        }
        
        .qualification-badge.qualified {
          background: rgba(16, 185, 129, 0.15);
          color: #34d399;
          border: 1px solid rgba(16, 185, 129, 0.3);
        }
        
        .qualification-badge.not-qualified {
          background: rgba(239, 68, 68, 0.15);
          color: #f87171;
          border: 1px solid rgba(239, 68, 68, 0.3);
        }
        
        .result-card {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 12px;
          padding: 1.25rem;
          text-align: center;
          margin-bottom: 1.5rem;
        }
        
        .result-card .label {
          font-size: 0.85rem;
          color: #94a3b8;
          margin-bottom: 0.5rem;
        }
        
        .result-card .value {
          font-size: 2.25rem;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          color: #60a5fa;
          text-shadow: 0 0 30px rgba(96, 165, 250, 0.3);
        }
        
        .result-card .sublabel {
          font-size: 0.8rem;
          color: #64748b;
          margin-top: 0.25rem;
        }
        
        .metrics-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
          margin-bottom: 1.5rem;
        }
        
        .metric {
          background: rgba(30, 41, 59, 0.5);
          border-radius: 10px;
          padding: 1rem;
        }
        
        .metric .label {
          font-size: 0.75rem;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 0.25rem;
        }
        
        .metric .value {
          font-size: 1.25rem;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          color: #f8fafc;
        }
        
        .dti-meter {
          margin-bottom: 1.5rem;
        }
        
        .dti-meter h4 {
          font-size: 0.85rem;
          color: #94a3b8;
          margin-bottom: 0.75rem;
        }
        
        .meter-bar {
          height: 10px;
          background: rgba(30, 41, 59, 0.8);
          border-radius: 5px;
          overflow: hidden;
          position: relative;
        }
        
        .meter-fill {
          height: 100%;
          border-radius: 5px;
          transition: width 0.5s ease;
        }
        
        .meter-fill.good {
          background: linear-gradient(90deg, #10b981, #34d399);
        }
        
        .meter-fill.warning {
          background: linear-gradient(90deg, #f59e0b, #fbbf24);
        }
        
        .meter-fill.danger {
          background: linear-gradient(90deg, #ef4444, #f87171);
        }
        
        .meter-markers {
          display: flex;
          justify-content: space-between;
          margin-top: 0.25rem;
          font-size: 0.7rem;
          color: #64748b;
        }
        
        .info-box {
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 10px;
          padding: 1rem;
        }
        
        .info-box h4 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.9rem;
          color: #60a5fa;
          margin-bottom: 0.75rem;
        }
        
        .info-box ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        
        .info-box li {
          display: flex;
          align-items: flex-start;
          gap: 0.5rem;
          font-size: 0.8rem;
          color: #94a3b8;
          margin-bottom: 0.5rem;
        }
        
        .info-box li svg {
          color: #10b981;
          flex-shrink: 0;
          margin-top: 2px;
        }
        
        .your-numbers {
          background: rgba(16, 185, 129, 0.1);
          border: 1px solid rgba(16, 185, 129, 0.2);
          border-radius: 12px;
          padding: 1.25rem;
          margin-top: 2rem;
        }
        
        .your-numbers h3 {
          font-size: 1rem;
          color: #34d399;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .your-numbers .breakdown {
          display: grid;
          gap: 0.5rem;
        }
        
        .breakdown-row {
          display: flex;
          justify-content: space-between;
          font-size: 0.9rem;
          padding: 0.5rem 0;
          border-bottom: 1px solid rgba(16, 185, 129, 0.1);
        }
        
        .breakdown-row:last-child {
          border-bottom: none;
        }
        
        .breakdown-row span:first-child {
          color: #94a3b8;
        }
        
        .breakdown-row span:last-child {
          color: #f8fafc;
          font-family: 'JetBrains Mono', monospace;
        }
      `}</style>
      
      <div className="calc-container">
        <div className="calc-header">
          <h1>🏠 NACA Affordability Calculator</h1>
          <p>Estimate your max loan amount with NACA's no-down-payment program</p>
        </div>
        
        <div className="calc-grid">
          <div className="input-section">
            <div className="section-title">
              <Briefcase size={20} />
              Your Financial Profile
            </div>
            
            <div className="input-group">
              <label>Annual Gross Income</label>
              <div className="input-row">
                <div className="input-wrapper">
                  <span className="prefix">$</span>
                  <input
                    type="number"
                    value={income}
                    onChange={(e) => setIncome(Number(e.target.value))}
                    min="0"
                    step="1000"
                  />
                </div>
              </div>
              <input
                type="range"
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                min="20000"
                max="200000"
                step="5000"
              />
            </div>
            
            <div className="input-group">
              <label>Monthly Debt Payments (car, credit cards, loans, etc.)</label>
              <div className="input-row">
                <div className="input-wrapper">
                  <span className="prefix">$</span>
                  <input
                    type="number"
                    value={monthlyDebts}
                    onChange={(e) => setMonthlyDebts(Number(e.target.value))}
                    min="0"
                    step="50"
                  />
                </div>
              </div>
              <input
                type="range"
                value={monthlyDebts}
                onChange={(e) => setMonthlyDebts(Number(e.target.value))}
                min="0"
                max="3000"
                step="50"
              />
            </div>
            
            <div className="input-group">
              <label>Expected Interest Rate (NACA is typically 1-2% below market)</label>
              <div className="input-row">
                <input
                  type="range"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  min="3"
                  max="8"
                  step="0.25"
                  style={{ flex: 1 }}
                />
                <span className="value-display">{interestRate.toFixed(2)}%</span>
              </div>
            </div>
            
            <div className="input-group">
              <label>Loan Term</label>
              <div className="input-row">
                <input
                  type="range"
                  value={loanTerm}
                  onChange={(e) => setLoanTerm(Number(e.target.value))}
                  min="15"
                  max="30"
                  step="5"
                  style={{ flex: 1 }}
                />
                <span className="value-display">{loanTerm} years</span>
              </div>
            </div>
            
            <div className="info-box">
              <h4><Info size={16} /> NACA Benefits</h4>
              <ul>
                <li><CheckCircle size={14} /> No down payment required</li>
                <li><CheckCircle size={14} /> No closing costs</li>
                <li><CheckCircle size={14} /> No PMI (Private Mortgage Insurance)</li>
                <li><CheckCircle size={14} /> Below-market interest rates</li>
                <li><CheckCircle size={14} /> Must be owner-occupied primary residence</li>
              </ul>
            </div>
          </div>
          
          <div className="results-section">
            <div className="section-title">
              <TrendingUp size={20} />
              Your Estimated Approval
            </div>
            
            <div className={`qualification-badge ${results.isQualified ? 'qualified' : 'not-qualified'}`}>
              {results.isQualified ? (
                <>
                  <CheckCircle size={20} />
                  You May Qualify for NACA!
                </>
              ) : (
                <>
                  <AlertTriangle size={20} />
                  Debt-to-Income Ratio Too High
                </>
              )}
            </div>
            
            <div className="result-card">
              <div className="label">Maximum Loan Amount</div>
              <div className="value">${results.maxLoanAmount.toLocaleString()}</div>
              <div className="sublabel">with ${results.effectiveMaxPayment}/mo payment</div>
            </div>
            
            <div className="metrics-grid">
              <div className="metric">
                <div className="label">Monthly Gross</div>
                <div className="value">${results.monthlyGross.toLocaleString()}</div>
              </div>
              <div className="metric">
                <div className="label">Max Housing Payment</div>
                <div className="value">${results.effectiveMaxPayment.toLocaleString()}</div>
              </div>
              <div className="metric">
                <div className="label">Front-End DTI</div>
                <div className="value">{results.frontEndDTI}%</div>
              </div>
              <div className="metric">
                <div className="label">Projected Back-End DTI</div>
                <div className="value">{results.projectedBackEndDTI}%</div>
              </div>
            </div>
            
            <div className="dti-meter">
              <h4>Current Debt-to-Income (Before Housing)</h4>
              <div className="meter-bar">
                <div 
                  className={`meter-fill ${
                    parseFloat(results.currentBackEndDTI) < 25 ? 'good' : 
                    parseFloat(results.currentBackEndDTI) < 36 ? 'warning' : 'danger'
                  }`}
                  style={{ width: `${Math.min(100, (parseFloat(results.currentBackEndDTI) / 50) * 100)}%` }}
                />
              </div>
              <div className="meter-markers">
                <span>0%</span>
                <span>25%</span>
                <span>36%</span>
                <span>43% max</span>
                <span>50%</span>
              </div>
            </div>
            
            <div className="dti-meter">
              <h4>Projected Debt-to-Income (With Housing)</h4>
              <div className="meter-bar">
                <div 
                  className={`meter-fill ${
                    parseFloat(results.projectedBackEndDTI) < 36 ? 'good' : 
                    parseFloat(results.projectedBackEndDTI) <= 43 ? 'warning' : 'danger'
                  }`}
                  style={{ width: `${Math.min(100, (parseFloat(results.projectedBackEndDTI) / 50) * 100)}%` }}
                />
              </div>
              <div className="meter-markers">
                <span>0%</span>
                <span>25%</span>
                <span>36%</span>
                <span>43% max</span>
                <span>50%</span>
              </div>
            </div>
            
            <div className="your-numbers">
              <h3><PiggyBank size={18} /> With Your Numbers ($55k income, $800/mo debts)</h3>
              <div className="breakdown">
                <div className="breakdown-row">
                  <span>Monthly gross income</span>
                  <span>${(55000/12).toLocaleString(undefined, {maximumFractionDigits: 0})}</span>
                </div>
                <div className="breakdown-row">
                  <span>Max housing (31% front-end)</span>
                  <span>${Math.round((55000/12) * 0.31).toLocaleString()}</span>
                </div>
                <div className="breakdown-row">
                  <span>Available after debts (43% back-end)</span>
                  <span>${Math.round((55000/12) * 0.43 - 800).toLocaleString()}</span>
                </div>
                <div className="breakdown-row">
                  <span>Effective max payment</span>
                  <span>${Math.min(Math.round((55000/12) * 0.31), Math.round((55000/12) * 0.43 - 800)).toLocaleString()}</span>
                </div>
                <div className="breakdown-row" style={{background: 'rgba(96, 165, 250, 0.1)', padding: '0.75rem', borderRadius: '8px', marginTop: '0.5rem'}}>
                  <span style={{color: '#60a5fa', fontWeight: '600'}}>Estimated max loan</span>
                  <span style={{color: '#60a5fa', fontWeight: '700', fontSize: '1.1rem'}}>~$115,000 - $125,000</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
