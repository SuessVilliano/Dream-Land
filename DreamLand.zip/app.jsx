import React, { useState, useEffect, useMemo } from 'react';
import { Search, MapPin, Calendar, DollarSign, Home, ExternalLink, Filter, TrendingUp, AlertTriangle, CheckCircle, Zap, ChevronDown, X, Star, Building, Trees, Shield, Wifi, Droplets, Map, List, Bell, Heart, BarChart3, Clock, Gavel, FileText } from 'lucide-react';

// Mock data representing aggregated auction data from multiple sources
const MOCK_PROPERTIES = [
  {
    id: 1,
    address: "7530 Judith Crescent",
    city: "Port Richey",
    state: "FL",
    county: "Pasco",
    zip: "34668",
    lat: 28.3086,
    lng: -82.7193,
    auctionType: "sheriff_sale",
    auctionDate: "2026-02-25",
    auctionTime: "10:00 AM",
    openingBid: 15420,
    estimatedValue: 89000,
    acres: 0.25,
    propertyType: "residential_lot",
    platform: "Pasco Sheriff's Office",
    platformUrl: "https://pascosheriff.com/sheriff-levy-sales/",
    caseNumber: "2022CA003266CAAXWS",
    taxesDue: 3240,
    zoning: "R-2",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: true, electric: true, sewer: false },
    floodZone: "X",
    aiScore: 87,
    aiAnalysis: {
      verdict: "Strong Buy",
      reasons: ["83% below market value", "RV/Mobile allowed", "No flood zone", "Utilities available"],
      risks: ["Sheriff sale - verify title", "May have existing liens"],
      investmentPotential: "High"
    }
  },
  {
    id: 2,
    address: "Gulf Side Villa Lot 22",
    city: "New Port Richey",
    state: "FL",
    county: "Pasco",
    zip: "34654",
    lat: 28.2442,
    lng: -82.7557,
    auctionType: "tax_deed",
    auctionDate: "2026-02-13",
    auctionTime: "10:00 AM",
    openingBid: 8750,
    estimatedValue: 32995,
    acres: 0.35,
    propertyType: "residential_lot",
    platform: "Pasco RealTaxDeed",
    platformUrl: "https://pasco.realtaxdeed.com",
    caseNumber: "TD-2025-0892",
    taxesDue: 2340,
    zoning: "AR",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: true, electric: true, sewer: true },
    floodZone: "X",
    waterfront: true,
    aiScore: 92,
    aiAnalysis: {
      verdict: "Excellent Opportunity",
      reasons: ["73% below market", "Waterfront with Gulf access", "All utilities", "No HOA"],
      risks: ["Tax deed - 2 year redemption period in FL"],
      investmentPotential: "Very High"
    }
  },
  {
    id: 3,
    address: "4301 Winters Chapel Rd",
    city: "Decatur",
    state: "GA",
    county: "DeKalb",
    zip: "30360",
    lat: 33.9012,
    lng: -84.2891,
    auctionType: "tax_deed",
    auctionDate: "2026-04-07",
    auctionTime: "10:00 AM",
    openingBid: 21756,
    estimatedValue: 145000,
    acres: 0.45,
    propertyType: "residential_lot",
    platform: "DeKalb Tax Commissioner",
    platformUrl: "https://dekalbtax.org/tax-sale-listing",
    caseNumber: "25-R30264499-APR",
    taxesDue: 21756,
    zoning: "R-75",
    mobileHomeAllowed: false,
    rvAllowed: false,
    utilities: { water: true, electric: true, sewer: true },
    floodZone: "X",
    aiScore: 78,
    aiAnalysis: {
      verdict: "Good Value",
      reasons: ["85% below market", "Metro Atlanta location", "Full utilities"],
      risks: ["12-month redemption period GA", "No mobile/RV allowed", "Higher taxes"],
      investmentPotential: "Medium-High"
    }
  },
  {
    id: 4,
    address: "136 Pryor St SW Lot 47",
    city: "Atlanta",
    state: "GA",
    county: "Fulton",
    zip: "30303",
    lat: 33.7537,
    lng: -84.3912,
    auctionType: "sheriff_sale",
    auctionDate: "2026-02-03",
    auctionTime: "10:00 AM",
    openingBid: 5420,
    estimatedValue: 28000,
    acres: 0.18,
    propertyType: "residential_lot",
    platform: "Fulton County Sheriff",
    platformUrl: "https://fultoncountyga.gov/inside-fulton-county/fulton-county-departments/sheriff/tax-sales",
    caseNumber: "FC-2025-TAX-1847",
    taxesDue: 5420,
    zoning: "R-4",
    mobileHomeAllowed: false,
    rvAllowed: false,
    utilities: { water: true, electric: true, sewer: true },
    floodZone: "X",
    aiScore: 72,
    aiAnalysis: {
      verdict: "Speculative",
      reasons: ["81% below market", "Downtown Atlanta proximity"],
      risks: ["Small lot", "No RV/Mobile", "Urban restrictions", "12-month redemption"],
      investmentPotential: "Medium"
    }
  },
  {
    id: 5,
    address: "Moon Lake Estates Lot 14",
    city: "New Port Richey",
    state: "FL",
    county: "Pasco",
    zip: "34654",
    lat: 28.2891,
    lng: -82.6842,
    auctionType: "tax_deed",
    auctionDate: "2026-02-20",
    auctionTime: "10:00 AM",
    openingBid: 4200,
    estimatedValue: 9800,
    acres: 0.17,
    propertyType: "residential_lot",
    platform: "Pasco RealTaxDeed",
    platformUrl: "https://pasco.realtaxdeed.com",
    caseNumber: "TD-2025-1024",
    taxesDue: 1850,
    zoning: "AR",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: false, electric: true, sewer: false },
    floodZone: "X",
    aiScore: 84,
    aiAnalysis: {
      verdict: "Great Starter",
      reasons: ["57% below market", "RV/Mobile allowed", "Very affordable entry"],
      risks: ["No water/sewer - need well & septic", "Small lot"],
      investmentPotential: "High for budget buyers"
    }
  },
  {
    id: 6,
    address: "1144 Embry Ct",
    city: "Ranger",
    state: "GA",
    county: "Gordon",
    zip: "30734",
    lat: 34.5012,
    lng: -84.7234,
    auctionType: "listing",
    auctionDate: null,
    auctionTime: null,
    openingBid: null,
    listPrice: 4999,
    estimatedValue: 12000,
    acres: 1.24,
    propertyType: "raw_land",
    platform: "LandSearch",
    platformUrl: "https://www.landsearch.com/properties/georgia",
    caseNumber: null,
    taxesDue: 0,
    zoning: "A-1",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: false, electric: false, sewer: false },
    floodZone: "X",
    aiScore: 88,
    aiAnalysis: {
      verdict: "Best Budget Pick",
      reasons: ["58% below market", "1.24 acres for under $5k", "Flexible zoning", "1hr from Atlanta"],
      risks: ["No utilities - full off-grid setup needed", "Rural location"],
      investmentPotential: "Excellent for off-grid living"
    }
  },
  {
    id: 7,
    address: "Hillsborough Tax Deed #2025-4521",
    city: "Tampa",
    state: "FL",
    county: "Hillsborough",
    zip: "33619",
    lat: 27.9567,
    lng: -82.3912,
    auctionType: "tax_deed",
    auctionDate: "2026-02-06",
    auctionTime: "10:00 AM",
    openingBid: 12450,
    estimatedValue: 65000,
    acres: 0.21,
    propertyType: "residential_lot",
    platform: "Hillsborough RealTaxDeed",
    platformUrl: "https://hillsborough.realtaxdeed.com",
    caseNumber: "TD-2025-4521",
    taxesDue: 8920,
    zoning: "RS-50",
    mobileHomeAllowed: false,
    rvAllowed: false,
    utilities: { water: true, electric: true, sewer: true },
    floodZone: "AE",
    aiScore: 65,
    aiAnalysis: {
      verdict: "Proceed with Caution",
      reasons: ["81% below market", "Tampa location", "Full utilities"],
      risks: ["FLOOD ZONE AE - requires flood insurance", "No RV/Mobile", "Higher development costs"],
      investmentPotential: "Medium - factor flood costs"
    }
  },
  {
    id: 8,
    address: "961 Trinton Dr",
    city: "Ranger",
    state: "GA",
    county: "Gordon",
    zip: "30734",
    lat: 34.4923,
    lng: -84.7156,
    auctionType: "listing",
    listPrice: 6999,
    estimatedValue: 15000,
    acres: 1.0,
    propertyType: "raw_land",
    platform: "LandSearch",
    platformUrl: "https://www.landsearch.com/properties/georgia",
    zoning: "A-1",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: false, electric: true, sewer: false },
    floodZone: "X",
    aiScore: 86,
    aiAnalysis: {
      verdict: "Strong Value",
      reasons: ["53% below market", "1 full acre", "Electric available", "Flexible zoning"],
      risks: ["Need well & septic", "Rural"],
      investmentPotential: "High"
    }
  },
  {
    id: 9,
    address: "Cobb County Tax Sale #2026-0234",
    city: "Marietta",
    state: "GA",
    county: "Cobb",
    zip: "30060",
    lat: 33.9526,
    lng: -84.5499,
    auctionType: "tax_deed",
    auctionDate: "2026-03-03",
    auctionTime: "10:00 AM",
    openingBid: 18900,
    estimatedValue: 95000,
    acres: 0.33,
    propertyType: "residential_lot",
    platform: "Cobb County Tax Commissioner",
    platformUrl: "https://www.cobbtax.gov/property/tax_sale/",
    caseNumber: "2026-0234",
    taxesDue: 18900,
    zoning: "R-20",
    mobileHomeAllowed: false,
    rvAllowed: false,
    utilities: { water: true, electric: true, sewer: true },
    floodZone: "X",
    aiScore: 80,
    aiAnalysis: {
      verdict: "Good Suburban Value",
      reasons: ["80% below market", "Marietta/Cobb location", "Full utilities", "Good schools"],
      risks: ["12-month redemption", "No RV/Mobile", "Suburban restrictions"],
      investmentPotential: "Medium-High for traditional build"
    }
  },
  {
    id: 10,
    address: "Brooksville Lot - Chimney Rock Dr",
    city: "Brooksville",
    state: "FL",
    county: "Hernando",
    zip: "34601",
    lat: 28.5553,
    lng: -82.3879,
    auctionType: "listing",
    listPrice: 12900,
    estimatedValue: 22000,
    acres: 0.52,
    propertyType: "residential_lot",
    platform: "LotFlip FSBO",
    platformUrl: "https://www.lotflip.com/lots-fsbo/florida/hernando-county",
    zoning: "R-1",
    mobileHomeAllowed: true,
    rvAllowed: true,
    utilities: { water: false, electric: true, sewer: false },
    floodZone: "X",
    aiScore: 85,
    aiAnalysis: {
      verdict: "Solid Choice",
      reasons: ["41% below market", "Mobile/RV allowed", "Owner financing available", "No HOA"],
      risks: ["Need well & septic"],
      investmentPotential: "High"
    }
  }
];

// Auction platform registry
const AUCTION_PLATFORMS = {
  florida: [
    { name: "Hillsborough RealTaxDeed", url: "https://hillsborough.realtaxdeed.com", type: "tax_deed", schedule: "Thursdays 10am" },
    { name: "Pasco RealTaxDeed", url: "https://pasco.realtaxdeed.com", type: "tax_deed", schedule: "Thursdays monthly" },
    { name: "Pasco RealForeclose", url: "https://pasco.realforeclose.com", type: "foreclosure", schedule: "Varies" },
    { name: "Pasco Sheriff Levy", url: "https://pascosheriff.com/sheriff-levy-sales/", type: "sheriff_sale", schedule: "As scheduled" },
    { name: "Hillsborough Surplus Lands", url: "https://hcfl.gov/government/real-estate/surplus-county-lands", type: "surplus", schedule: "Sealed bid" },
    { name: "Hernando RealTaxDeed", url: "https://hernando.realtaxdeed.com", type: "tax_deed", schedule: "Monthly" },
    { name: "Polk RealTaxDeed", url: "https://polk.realtaxdeed.com", type: "tax_deed", schedule: "Monthly" },
  ],
  georgia: [
    { name: "Fulton County Sheriff", url: "https://fultoncountyga.gov/inside-fulton-county/fulton-county-departments/sheriff/tax-sales", type: "tax_deed", schedule: "1st Tuesday monthly" },
    { name: "DeKalb Tax Commissioner", url: "https://dekalbtax.org/tax-sale-listing", type: "tax_deed", schedule: "Monthly" },
    { name: "Cobb Tax Commissioner", url: "https://www.cobbtax.gov/property/tax_sale/", type: "tax_deed", schedule: "Varies" },
    { name: "DeKalb County Surplus", url: "https://www.dekalbcountyga.gov/gis/how-purchase-county-owned-property", type: "surplus", schedule: "As available" },
  ]
};

// Components
const ScoreGauge = ({ score }) => {
  const getColor = (s) => {
    if (s >= 85) return '#10b981';
    if (s >= 70) return '#f59e0b';
    return '#ef4444';
  };
  
  return (
    <div className="score-gauge">
      <svg viewBox="0 0 100 50" className="gauge-svg">
        <path
          d="M 10 45 A 35 35 0 0 1 90 45"
          fill="none"
          stroke="#1e293b"
          strokeWidth="8"
          strokeLinecap="round"
        />
        <path
          d="M 10 45 A 35 35 0 0 1 90 45"
          fill="none"
          stroke={getColor(score)}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${score * 1.1} 110`}
          style={{ filter: `drop-shadow(0 0 6px ${getColor(score)})` }}
        />
      </svg>
      <div className="score-value" style={{ color: getColor(score) }}>{score}</div>
      <div className="score-label">AI Score</div>
    </div>
  );
};

const PropertyCard = ({ property, onSelect, isSelected }) => {
  const price = property.openingBid || property.listPrice;
  const discount = Math.round((1 - price / property.estimatedValue) * 100);
  
  const getTypeIcon = () => {
    switch(property.auctionType) {
      case 'sheriff_sale': return <Shield size={14} />;
      case 'tax_deed': return <Gavel size={14} />;
      case 'foreclosure': return <Building size={14} />;
      default: return <FileText size={14} />;
    }
  };
  
  const getTypeLabel = () => {
    switch(property.auctionType) {
      case 'sheriff_sale': return 'Sheriff Sale';
      case 'tax_deed': return 'Tax Deed';
      case 'foreclosure': return 'Foreclosure';
      default: return 'Listing';
    }
  };

  return (
    <div 
      className={`property-card ${isSelected ? 'selected' : ''}`}
      onClick={() => onSelect(property)}
    >
      <div className="card-header">
        <div className="auction-badge" data-type={property.auctionType}>
          {getTypeIcon()}
          <span>{getTypeLabel()}</span>
        </div>
        <div className="discount-badge">-{discount}%</div>
      </div>
      
      <div className="card-body">
        <h3 className="property-address">{property.address}</h3>
        <p className="property-location">
          <MapPin size={12} />
          {property.city}, {property.state} {property.zip}
        </p>
        
        <div className="property-stats">
          <div className="stat">
            <span className="stat-value">${price?.toLocaleString()}</span>
            <span className="stat-label">{property.auctionType === 'listing' ? 'Price' : 'Opening Bid'}</span>
          </div>
          <div className="stat">
            <span className="stat-value">{property.acres} ac</span>
            <span className="stat-label">Size</span>
          </div>
          <div className="stat">
            <span className="stat-value">${property.estimatedValue?.toLocaleString()}</span>
            <span className="stat-label">Est. Value</span>
          </div>
        </div>
        
        <div className="property-tags">
          {property.mobileHomeAllowed && <span className="tag tag-green"><Home size={10} /> Mobile OK</span>}
          {property.rvAllowed && <span className="tag tag-green"><Trees size={10} /> RV OK</span>}
          {property.floodZone === 'X' && <span className="tag tag-blue"><Droplets size={10} /> No Flood</span>}
          {property.floodZone !== 'X' && <span className="tag tag-red"><AlertTriangle size={10} /> Flood Zone</span>}
          {property.waterfront && <span className="tag tag-cyan"><Droplets size={10} /> Waterfront</span>}
        </div>
        
        {property.auctionDate && (
          <div className="auction-date">
            <Calendar size={12} />
            <span>{new Date(property.auctionDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} @ {property.auctionTime}</span>
          </div>
        )}
      </div>
      
      <div className="card-footer">
        <div className="ai-verdict" data-verdict={property.aiAnalysis?.verdict?.toLowerCase().replace(/\s+/g, '-')}>
          <Zap size={12} />
          <span>{property.aiAnalysis?.verdict}</span>
        </div>
        <ScoreGauge score={property.aiScore} />
      </div>
    </div>
  );
};

const PropertyDetail = ({ property, onClose }) => {
  if (!property) return null;
  
  const price = property.openingBid || property.listPrice;
  
  return (
    <div className="property-detail">
      <button className="close-btn" onClick={onClose}><X size={20} /></button>
      
      <div className="detail-header">
        <div>
          <h2>{property.address}</h2>
          <p className="detail-location">
            <MapPin size={14} />
            {property.city}, {property.county} County, {property.state} {property.zip}
          </p>
        </div>
        <ScoreGauge score={property.aiScore} />
      </div>
      
      <div className="detail-grid">
        <div className="detail-section">
          <h3><DollarSign size={16} /> Pricing</h3>
          <div className="detail-row">
            <span>{property.auctionType === 'listing' ? 'List Price' : 'Opening Bid'}</span>
            <strong>${price?.toLocaleString()}</strong>
          </div>
          <div className="detail-row">
            <span>Estimated Value</span>
            <strong>${property.estimatedValue?.toLocaleString()}</strong>
          </div>
          <div className="detail-row highlight">
            <span>Potential Savings</span>
            <strong className="savings">${(property.estimatedValue - price)?.toLocaleString()}</strong>
          </div>
          {property.taxesDue > 0 && (
            <div className="detail-row">
              <span>Taxes Due</span>
              <strong>${property.taxesDue?.toLocaleString()}</strong>
            </div>
          )}
        </div>
        
        <div className="detail-section">
          <h3><Home size={16} /> Property Details</h3>
          <div className="detail-row">
            <span>Acreage</span>
            <strong>{property.acres} acres</strong>
          </div>
          <div className="detail-row">
            <span>Zoning</span>
            <strong>{property.zoning}</strong>
          </div>
          <div className="detail-row">
            <span>Mobile Home</span>
            <strong className={property.mobileHomeAllowed ? 'yes' : 'no'}>
              {property.mobileHomeAllowed ? '✓ Allowed' : '✗ Not Allowed'}
            </strong>
          </div>
          <div className="detail-row">
            <span>RV Living</span>
            <strong className={property.rvAllowed ? 'yes' : 'no'}>
              {property.rvAllowed ? '✓ Allowed' : '✗ Not Allowed'}
            </strong>
          </div>
          <div className="detail-row">
            <span>Flood Zone</span>
            <strong className={property.floodZone === 'X' ? 'yes' : 'no'}>
              {property.floodZone} {property.floodZone === 'X' ? '(Minimal Risk)' : '(Elevated Risk)'}
            </strong>
          </div>
        </div>
        
        <div className="detail-section">
          <h3><Wifi size={16} /> Utilities</h3>
          <div className="utilities-grid">
            <div className={`utility ${property.utilities?.water ? 'available' : 'unavailable'}`}>
              <Droplets size={16} />
              <span>Water</span>
            </div>
            <div className={`utility ${property.utilities?.electric ? 'available' : 'unavailable'}`}>
              <Zap size={16} />
              <span>Electric</span>
            </div>
            <div className={`utility ${property.utilities?.sewer ? 'available' : 'unavailable'}`}>
              <Building size={16} />
              <span>Sewer</span>
            </div>
          </div>
        </div>
        
        <div className="detail-section">
          <h3><Gavel size={16} /> Auction Info</h3>
          <div className="detail-row">
            <span>Platform</span>
            <strong>{property.platform}</strong>
          </div>
          {property.auctionDate && (
            <>
              <div className="detail-row">
                <span>Auction Date</span>
                <strong>{new Date(property.auctionDate).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</strong>
              </div>
              <div className="detail-row">
                <span>Auction Time</span>
                <strong>{property.auctionTime}</strong>
              </div>
            </>
          )}
          {property.caseNumber && (
            <div className="detail-row">
              <span>Case/ID</span>
              <strong>{property.caseNumber}</strong>
            </div>
          )}
        </div>
      </div>
      
      <div className="ai-analysis-section">
        <h3><BarChart3 size={16} /> AI Analysis</h3>
        <div className="ai-verdict-large" data-verdict={property.aiAnalysis?.verdict?.toLowerCase().replace(/\s+/g, '-')}>
          {property.aiAnalysis?.verdict}
        </div>
        
        <div className="analysis-columns">
          <div className="analysis-col">
            <h4><CheckCircle size={14} /> Reasons to Buy</h4>
            <ul>
              {property.aiAnalysis?.reasons?.map((reason, i) => (
                <li key={i}>{reason}</li>
              ))}
            </ul>
          </div>
          <div className="analysis-col risks">
            <h4><AlertTriangle size={14} /> Risk Factors</h4>
            <ul>
              {property.aiAnalysis?.risks?.map((risk, i) => (
                <li key={i}>{risk}</li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="investment-potential">
          <span>Investment Potential:</span>
          <strong>{property.aiAnalysis?.investmentPotential}</strong>
        </div>
      </div>
      
      <div className="action-buttons">
        <a href={property.platformUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
          <ExternalLink size={16} />
          View on {property.platform}
        </a>
        <button className="btn btn-secondary">
          <Heart size={16} />
          Save Property
        </button>
        <button className="btn btn-secondary">
          <Bell size={16} />
          Set Alert
        </button>
      </div>
    </div>
  );
};

const PlatformDirectory = ({ state }) => {
  const platforms = AUCTION_PLATFORMS[state] || [];
  
  return (
    <div className="platform-directory">
      <h3><ExternalLink size={16} /> {state === 'florida' ? 'Florida' : 'Georgia'} Auction Platforms</h3>
      <div className="platform-list">
        {platforms.map((platform, i) => (
          <a key={i} href={platform.url} target="_blank" rel="noopener noreferrer" className="platform-link">
            <div className="platform-info">
              <span className="platform-name">{platform.name}</span>
              <span className="platform-type">{platform.type.replace('_', ' ')}</span>
            </div>
            <span className="platform-schedule">{platform.schedule}</span>
            <ExternalLink size={14} />
          </a>
        ))}
      </div>
    </div>
  );
};

// Main App
export default function LandScoutApp() {
  const [properties, setProperties] = useState(MOCK_PROPERTIES);
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [viewMode, setViewMode] = useState('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    state: 'all',
    auctionType: 'all',
    maxPrice: 100000,
    minAcres: 0,
    rvAllowed: false,
    mobileHomeAllowed: false,
    noFloodZone: false,
    minScore: 0
  });
  
  const filteredProperties = useMemo(() => {
    return properties.filter(p => {
      const price = p.openingBid || p.listPrice;
      if (filters.state !== 'all' && p.state !== filters.state) return false;
      if (filters.auctionType !== 'all' && p.auctionType !== filters.auctionType) return false;
      if (price > filters.maxPrice) return false;
      if (p.acres < filters.minAcres) return false;
      if (filters.rvAllowed && !p.rvAllowed) return false;
      if (filters.mobileHomeAllowed && !p.mobileHomeAllowed) return false;
      if (filters.noFloodZone && p.floodZone !== 'X') return false;
      if (p.aiScore < filters.minScore) return false;
      return true;
    }).sort((a, b) => b.aiScore - a.aiScore);
  }, [properties, filters]);

  const stats = useMemo(() => ({
    total: filteredProperties.length,
    avgScore: Math.round(filteredProperties.reduce((sum, p) => sum + p.aiScore, 0) / filteredProperties.length) || 0,
    avgDiscount: Math.round(filteredProperties.reduce((sum, p) => {
      const price = p.openingBid || p.listPrice;
      return sum + (1 - price / p.estimatedValue) * 100;
    }, 0) / filteredProperties.length) || 0,
    rvFriendly: filteredProperties.filter(p => p.rvAllowed).length
  }), [filteredProperties]);

  return (
    <div className="land-scout-app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        .land-scout-app {
          font-family: 'Space Grotesk', sans-serif;
          background: linear-gradient(135deg, #0a0f1a 0%, #0d1524 50%, #0f1a2e 100%);
          min-height: 100vh;
          color: #e2e8f0;
        }
        
        /* Header */
        .app-header {
          background: rgba(15, 23, 42, 0.8);
          backdrop-filter: blur(20px);
          border-bottom: 1px solid rgba(59, 130, 246, 0.2);
          padding: 1rem 2rem;
          position: sticky;
          top: 0;
          z-index: 100;
        }
        
        .header-content {
          max-width: 1600px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 2rem;
        }
        
        .logo {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }
        
        .logo-icon {
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #3b82f6, #8b5cf6);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }
        
        .logo h1 {
          font-size: 1.5rem;
          font-weight: 700;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          letter-spacing: -0.5px;
        }
        
        .search-bar {
          flex: 1;
          max-width: 500px;
          position: relative;
        }
        
        .search-bar input {
          width: 100%;
          padding: 0.75rem 1rem 0.75rem 2.75rem;
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 12px;
          color: #e2e8f0;
          font-size: 0.95rem;
          font-family: inherit;
          transition: all 0.2s;
        }
        
        .search-bar input:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
        
        .search-bar input::placeholder {
          color: #64748b;
        }
        
        .search-bar svg {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: #64748b;
        }
        
        .header-actions {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        
        .view-toggle {
          display: flex;
          background: rgba(30, 41, 59, 0.8);
          border-radius: 8px;
          padding: 4px;
        }
        
        .view-toggle button {
          padding: 0.5rem 0.75rem;
          background: transparent;
          border: none;
          color: #64748b;
          cursor: pointer;
          border-radius: 6px;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.85rem;
          transition: all 0.2s;
        }
        
        .view-toggle button.active {
          background: #3b82f6;
          color: white;
        }
        
        .filter-btn {
          padding: 0.75rem 1.25rem;
          background: rgba(59, 130, 246, 0.2);
          border: 1px solid rgba(59, 130, 246, 0.3);
          color: #60a5fa;
          border-radius: 10px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.9rem;
          font-weight: 500;
          transition: all 0.2s;
        }
        
        .filter-btn:hover {
          background: rgba(59, 130, 246, 0.3);
        }
        
        /* Stats Bar */
        .stats-bar {
          background: rgba(15, 23, 42, 0.6);
          padding: 1rem 2rem;
          border-bottom: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .stats-content {
          max-width: 1600px;
          margin: 0 auto;
          display: flex;
          gap: 3rem;
        }
        
        .stat-item {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }
        
        .stat-item svg {
          color: #3b82f6;
        }
        
        .stat-item .stat-value {
          font-size: 1.25rem;
          font-weight: 600;
          color: #f8fafc;
        }
        
        .stat-item .stat-label {
          font-size: 0.8rem;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        /* Main Content */
        .main-content {
          max-width: 1600px;
          margin: 0 auto;
          padding: 2rem;
          display: grid;
          grid-template-columns: 1fr 400px;
          gap: 2rem;
        }
        
        .main-content.detail-open {
          grid-template-columns: 1fr 500px;
        }
        
        /* Filters Panel */
        .filters-panel {
          background: rgba(15, 23, 42, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 16px;
          padding: 1.5rem;
          margin-bottom: 1.5rem;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
        }
        
        .filter-group label {
          display: block;
          font-size: 0.8rem;
          color: #94a3b8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 0.5rem;
        }
        
        .filter-group select,
        .filter-group input[type="range"] {
          width: 100%;
          padding: 0.6rem;
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 8px;
          color: #e2e8f0;
          font-family: inherit;
        }
        
        .filter-group select:focus {
          outline: none;
          border-color: #3b82f6;
        }
        
        .range-value {
          font-family: 'JetBrains Mono', monospace;
          color: #60a5fa;
          font-size: 0.9rem;
        }
        
        .checkbox-group {
          display: flex;
          flex-wrap: wrap;
          gap: 0.75rem;
        }
        
        .checkbox-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 0.75rem;
          background: rgba(30, 41, 59, 0.6);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 8px;
          cursor: pointer;
          font-size: 0.85rem;
          transition: all 0.2s;
        }
        
        .checkbox-label:has(input:checked) {
          background: rgba(59, 130, 246, 0.2);
          border-color: #3b82f6;
        }
        
        .checkbox-label input {
          accent-color: #3b82f6;
        }
        
        /* Property Grid */
        .properties-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 1.5rem;
        }
        
        .property-card {
          background: rgba(15, 23, 42, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.15);
          border-radius: 16px;
          overflow: hidden;
          cursor: pointer;
          transition: all 0.3s;
        }
        
        .property-card:hover {
          border-color: rgba(59, 130, 246, 0.4);
          transform: translateY(-4px);
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
        }
        
        .property-card.selected {
          border-color: #3b82f6;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
        }
        
        .card-header {
          padding: 1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: rgba(30, 41, 59, 0.5);
        }
        
        .auction-badge {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .auction-badge[data-type="sheriff_sale"] {
          background: rgba(239, 68, 68, 0.2);
          color: #f87171;
        }
        
        .auction-badge[data-type="tax_deed"] {
          background: rgba(245, 158, 11, 0.2);
          color: #fbbf24;
        }
        
        .auction-badge[data-type="foreclosure"] {
          background: rgba(139, 92, 246, 0.2);
          color: #a78bfa;
        }
        
        .auction-badge[data-type="listing"] {
          background: rgba(34, 197, 94, 0.2);
          color: #4ade80;
        }
        
        .discount-badge {
          background: linear-gradient(135deg, #10b981, #059669);
          color: white;
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
        }
        
        .card-body {
          padding: 1.25rem;
        }
        
        .property-address {
          font-size: 1.05rem;
          font-weight: 600;
          color: #f8fafc;
          margin-bottom: 0.5rem;
          line-height: 1.3;
        }
        
        .property-location {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          color: #64748b;
          font-size: 0.85rem;
          margin-bottom: 1rem;
        }
        
        .property-stats {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 0.75rem;
          margin-bottom: 1rem;
        }
        
        .property-stats .stat {
          text-align: center;
        }
        
        .property-stats .stat-value {
          display: block;
          font-size: 1rem;
          font-weight: 600;
          color: #f8fafc;
          font-family: 'JetBrains Mono', monospace;
        }
        
        .property-stats .stat-label {
          font-size: 0.7rem;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .property-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
          margin-bottom: 1rem;
        }
        
        .tag {
          display: flex;
          align-items: center;
          gap: 0.3rem;
          padding: 0.25rem 0.6rem;
          border-radius: 6px;
          font-size: 0.7rem;
          font-weight: 500;
        }
        
        .tag-green {
          background: rgba(34, 197, 94, 0.15);
          color: #4ade80;
        }
        
        .tag-blue {
          background: rgba(59, 130, 246, 0.15);
          color: #60a5fa;
        }
        
        .tag-red {
          background: rgba(239, 68, 68, 0.15);
          color: #f87171;
        }
        
        .tag-cyan {
          background: rgba(6, 182, 212, 0.15);
          color: #22d3ee;
        }
        
        .auction-date {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #94a3b8;
          font-size: 0.8rem;
        }
        
        .card-footer {
          padding: 1rem 1.25rem;
          background: rgba(30, 41, 59, 0.3);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .ai-verdict {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          padding: 0.4rem 0.75rem;
          border-radius: 8px;
          font-size: 0.8rem;
          font-weight: 600;
        }
        
        .ai-verdict[data-verdict="excellent-opportunity"],
        .ai-verdict[data-verdict="strong-buy"],
        .ai-verdict[data-verdict="best-budget-pick"] {
          background: rgba(16, 185, 129, 0.2);
          color: #34d399;
        }
        
        .ai-verdict[data-verdict="great-starter"],
        .ai-verdict[data-verdict="solid-choice"],
        .ai-verdict[data-verdict="strong-value"],
        .ai-verdict[data-verdict="good-value"],
        .ai-verdict[data-verdict="good-suburban-value"] {
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
        }
        
        .ai-verdict[data-verdict="speculative"],
        .ai-verdict[data-verdict="proceed-with-caution"] {
          background: rgba(245, 158, 11, 0.2);
          color: #fbbf24;
        }
        
        /* Score Gauge */
        .score-gauge {
          position: relative;
          width: 60px;
          height: 35px;
        }
        
        .gauge-svg {
          width: 100%;
          height: 100%;
        }
        
        .score-value {
          position: absolute;
          bottom: 0;
          left: 50%;
          transform: translateX(-50%);
          font-size: 0.9rem;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
        }
        
        .score-label {
          display: none;
        }
        
        /* Property Detail Panel */
        .property-detail {
          background: rgba(15, 23, 42, 0.95);
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 20px;
          padding: 1.5rem;
          position: sticky;
          top: 100px;
          max-height: calc(100vh - 120px);
          overflow-y: auto;
        }
        
        .close-btn {
          position: absolute;
          top: 1rem;
          right: 1rem;
          background: rgba(30, 41, 59, 0.8);
          border: none;
          color: #94a3b8;
          width: 32px;
          height: 32px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        
        .close-btn:hover {
          background: #ef4444;
          color: white;
        }
        
        .detail-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 1.5rem;
          padding-right: 2.5rem;
        }
        
        .detail-header h2 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #f8fafc;
          margin-bottom: 0.5rem;
        }
        
        .detail-location {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          color: #64748b;
          font-size: 0.85rem;
        }
        
        .detail-header .score-gauge {
          width: 80px;
          height: 45px;
        }
        
        .detail-header .score-value {
          font-size: 1.1rem;
        }
        
        .detail-grid {
          display: grid;
          gap: 1.25rem;
          margin-bottom: 1.5rem;
        }
        
        .detail-section {
          background: rgba(30, 41, 59, 0.5);
          border-radius: 12px;
          padding: 1rem;
        }
        
        .detail-section h3 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.9rem;
          font-weight: 600;
          color: #94a3b8;
          margin-bottom: 0.75rem;
          padding-bottom: 0.5rem;
          border-bottom: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .detail-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.5rem 0;
          border-bottom: 1px solid rgba(59, 130, 246, 0.05);
        }
        
        .detail-row:last-child {
          border-bottom: none;
        }
        
        .detail-row span {
          color: #64748b;
          font-size: 0.85rem;
        }
        
        .detail-row strong {
          color: #f8fafc;
          font-size: 0.9rem;
        }
        
        .detail-row.highlight {
          background: rgba(16, 185, 129, 0.1);
          margin: 0.25rem -0.5rem;
          padding: 0.5rem;
          border-radius: 6px;
        }
        
        .detail-row .savings {
          color: #10b981;
          font-size: 1rem;
        }
        
        .detail-row strong.yes {
          color: #10b981;
        }
        
        .detail-row strong.no {
          color: #ef4444;
        }
        
        .utilities-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 0.5rem;
        }
        
        .utility {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.3rem;
          padding: 0.75rem;
          border-radius: 8px;
          font-size: 0.75rem;
        }
        
        .utility.available {
          background: rgba(16, 185, 129, 0.15);
          color: #10b981;
        }
        
        .utility.unavailable {
          background: rgba(239, 68, 68, 0.1);
          color: #64748b;
        }
        
        /* AI Analysis Section */
        .ai-analysis-section {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 12px;
          padding: 1.25rem;
          margin-bottom: 1.5rem;
        }
        
        .ai-analysis-section h3 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.9rem;
          font-weight: 600;
          color: #94a3b8;
          margin-bottom: 1rem;
        }
        
        .ai-verdict-large {
          font-size: 1.25rem;
          font-weight: 700;
          padding: 0.75rem 1rem;
          border-radius: 10px;
          text-align: center;
          margin-bottom: 1rem;
        }
        
        .ai-verdict-large[data-verdict="excellent-opportunity"],
        .ai-verdict-large[data-verdict="strong-buy"],
        .ai-verdict-large[data-verdict="best-budget-pick"] {
          background: rgba(16, 185, 129, 0.2);
          color: #34d399;
        }
        
        .ai-verdict-large[data-verdict="great-starter"],
        .ai-verdict-large[data-verdict="solid-choice"],
        .ai-verdict-large[data-verdict="strong-value"],
        .ai-verdict-large[data-verdict="good-value"],
        .ai-verdict-large[data-verdict="good-suburban-value"] {
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
        }
        
        .ai-verdict-large[data-verdict="speculative"],
        .ai-verdict-large[data-verdict="proceed-with-caution"] {
          background: rgba(245, 158, 11, 0.2);
          color: #fbbf24;
        }
        
        .analysis-columns {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
          margin-bottom: 1rem;
        }
        
        .analysis-col h4 {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          font-size: 0.8rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
        }
        
        .analysis-col ul {
          list-style: none;
          font-size: 0.8rem;
        }
        
        .analysis-col li {
          padding: 0.3rem 0;
          padding-left: 1rem;
          position: relative;
          color: #94a3b8;
        }
        
        .analysis-col li::before {
          content: '•';
          position: absolute;
          left: 0;
          color: #10b981;
        }
        
        .analysis-col.risks li::before {
          color: #f59e0b;
        }
        
        .investment-potential {
          background: rgba(30, 41, 59, 0.5);
          padding: 0.75rem;
          border-radius: 8px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .investment-potential span {
          color: #64748b;
          font-size: 0.85rem;
        }
        
        .investment-potential strong {
          color: #60a5fa;
        }
        
        /* Action Buttons */
        .action-buttons {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.875rem 1.25rem;
          border-radius: 10px;
          font-size: 0.9rem;
          font-weight: 600;
          font-family: inherit;
          cursor: pointer;
          text-decoration: none;
          transition: all 0.2s;
        }
        
        .btn-primary {
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          border: none;
          color: white;
          box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        .btn-secondary {
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.3);
          color: #94a3b8;
        }
        
        .btn-secondary:hover {
          border-color: #3b82f6;
          color: #60a5fa;
        }
        
        /* Platform Directory */
        .sidebar {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        .platform-directory {
          background: rgba(15, 23, 42, 0.8);
          border: 1px solid rgba(59, 130, 246, 0.15);
          border-radius: 16px;
          padding: 1.25rem;
        }
        
        .platform-directory h3 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.95rem;
          font-weight: 600;
          color: #f8fafc;
          margin-bottom: 1rem;
        }
        
        .platform-list {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }
        
        .platform-link {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.75rem;
          background: rgba(30, 41, 59, 0.5);
          border: 1px solid rgba(59, 130, 246, 0.1);
          border-radius: 10px;
          text-decoration: none;
          transition: all 0.2s;
        }
        
        .platform-link:hover {
          background: rgba(59, 130, 246, 0.1);
          border-color: rgba(59, 130, 246, 0.3);
        }
        
        .platform-info {
          flex: 1;
        }
        
        .platform-name {
          display: block;
          color: #f8fafc;
          font-size: 0.85rem;
          font-weight: 500;
        }
        
        .platform-type {
          color: #64748b;
          font-size: 0.7rem;
          text-transform: capitalize;
        }
        
        .platform-schedule {
          color: #94a3b8;
          font-size: 0.75rem;
        }
        
        .platform-link svg {
          color: #3b82f6;
        }
        
        /* Empty State */
        .empty-state {
          grid-column: 1 / -1;
          text-align: center;
          padding: 4rem 2rem;
          color: #64748b;
        }
        
        .empty-state svg {
          width: 64px;
          height: 64px;
          margin-bottom: 1rem;
          opacity: 0.5;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.5);
        }
        
        ::-webkit-scrollbar-thumb {
          background: rgba(59, 130, 246, 0.3);
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(59, 130, 246, 0.5);
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
          .main-content {
            grid-template-columns: 1fr;
          }
          
          .sidebar {
            display: none;
          }
        }
        
        @media (max-width: 768px) {
          .header-content {
            flex-wrap: wrap;
          }
          
          .search-bar {
            order: 3;
            max-width: 100%;
            width: 100%;
          }
          
          .stats-content {
            flex-wrap: wrap;
            gap: 1.5rem;
          }
          
          .filters-panel {
            grid-template-columns: 1fr;
          }
          
          .properties-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
      
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">
              <Map size={22} color="white" />
            </div>
            <h1>LandScout</h1>
          </div>
          
          <div className="search-bar">
            <Search size={18} />
            <input 
              type="text" 
              placeholder="Search by address, county, or state..."
            />
          </div>
          
          <div className="header-actions">
            <div className="view-toggle">
              <button 
                className={viewMode === 'grid' ? 'active' : ''}
                onClick={() => setViewMode('grid')}
              >
                <List size={16} /> Grid
              </button>
              <button 
                className={viewMode === 'map' ? 'active' : ''}
                onClick={() => setViewMode('map')}
              >
                <Map size={16} /> Map
              </button>
            </div>
            <button 
              className="filter-btn"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter size={16} />
              Filters
              <ChevronDown size={14} />
            </button>
          </div>
        </div>
      </header>
      
      {/* Stats Bar */}
      <div className="stats-bar">
        <div className="stats-content">
          <div className="stat-item">
            <Building size={20} />
            <div>
              <div className="stat-value">{stats.total}</div>
              <div className="stat-label">Properties</div>
            </div>
          </div>
          <div className="stat-item">
            <TrendingUp size={20} />
            <div>
              <div className="stat-value">{stats.avgDiscount}%</div>
              <div className="stat-label">Avg Discount</div>
            </div>
          </div>
          <div className="stat-item">
            <Zap size={20} />
            <div>
              <div className="stat-value">{stats.avgScore}</div>
              <div className="stat-label">Avg AI Score</div>
            </div>
          </div>
          <div className="stat-item">
            <Trees size={20} />
            <div>
              <div className="stat-value">{stats.rvFriendly}</div>
              <div className="stat-label">RV Friendly</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <main className={`main-content ${selectedProperty ? 'detail-open' : ''}`}>
        <div className="properties-section">
          {/* Filters Panel */}
          {showFilters && (
            <div className="filters-panel">
              <div className="filter-group">
                <label>State</label>
                <select 
                  value={filters.state}
                  onChange={(e) => setFilters({...filters, state: e.target.value})}
                >
                  <option value="all">All States</option>
                  <option value="FL">Florida</option>
                  <option value="GA">Georgia</option>
                </select>
              </div>
              
              <div className="filter-group">
                <label>Auction Type</label>
                <select
                  value={filters.auctionType}
                  onChange={(e) => setFilters({...filters, auctionType: e.target.value})}
                >
                  <option value="all">All Types</option>
                  <option value="tax_deed">Tax Deed</option>
                  <option value="sheriff_sale">Sheriff Sale</option>
                  <option value="foreclosure">Foreclosure</option>
                  <option value="listing">Listing</option>
                </select>
              </div>
              
              <div className="filter-group">
                <label>Max Price: <span className="range-value">${filters.maxPrice.toLocaleString()}</span></label>
                <input 
                  type="range" 
                  min="5000" 
                  max="100000" 
                  step="5000"
                  value={filters.maxPrice}
                  onChange={(e) => setFilters({...filters, maxPrice: parseInt(e.target.value)})}
                />
              </div>
              
              <div className="filter-group">
                <label>Min Acres: <span className="range-value">{filters.minAcres} ac</span></label>
                <input 
                  type="range" 
                  min="0" 
                  max="5" 
                  step="0.25"
                  value={filters.minAcres}
                  onChange={(e) => setFilters({...filters, minAcres: parseFloat(e.target.value)})}
                />
              </div>
              
              <div className="filter-group">
                <label>Min AI Score: <span className="range-value">{filters.minScore}</span></label>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  step="5"
                  value={filters.minScore}
                  onChange={(e) => setFilters({...filters, minScore: parseInt(e.target.value)})}
                />
              </div>
              
              <div className="filter-group">
                <label>Requirements</label>
                <div className="checkbox-group">
                  <label className="checkbox-label">
                    <input 
                      type="checkbox"
                      checked={filters.rvAllowed}
                      onChange={(e) => setFilters({...filters, rvAllowed: e.target.checked})}
                    />
                    RV Allowed
                  </label>
                  <label className="checkbox-label">
                    <input 
                      type="checkbox"
                      checked={filters.mobileHomeAllowed}
                      onChange={(e) => setFilters({...filters, mobileHomeAllowed: e.target.checked})}
                    />
                    Mobile Home OK
                  </label>
                  <label className="checkbox-label">
                    <input 
                      type="checkbox"
                      checked={filters.noFloodZone}
                      onChange={(e) => setFilters({...filters, noFloodZone: e.target.checked})}
                    />
                    No Flood Zone
                  </label>
                </div>
              </div>
            </div>
          )}
          
          {/* Property Grid */}
          <div className="properties-grid">
            {filteredProperties.length > 0 ? (
              filteredProperties.map(property => (
                <PropertyCard 
                  key={property.id}
                  property={property}
                  onSelect={setSelectedProperty}
                  isSelected={selectedProperty?.id === property.id}
                />
              ))
            ) : (
              <div className="empty-state">
                <Search />
                <h3>No properties match your filters</h3>
                <p>Try adjusting your search criteria</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Sidebar / Detail Panel */}
        <div className="sidebar">
          {selectedProperty ? (
            <PropertyDetail 
              property={selectedProperty}
              onClose={() => setSelectedProperty(null)}
            />
          ) : (
            <>
              <PlatformDirectory state="florida" />
              <PlatformDirectory state="georgia" />
            </>
          )}
        </div>
      </main>
    </div>
  );
}
